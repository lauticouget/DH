<!--Programa de ejemplo de formulario para mis alumnos de DH-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<title>trabajando con Formulario usando el metodo Post</title>
</head>

<body>
<form action="calculo_aumento.php" method="post" name="captura_aumento" target="_blank">
<table width="77%" border="6" align="center" bordercolor="#000066" bgcolor="#FFFFCC">
  <tr>
    <th width="30%" scope="row"><div align="left">DNI:</div></th>
    <td width="70%"><input name="dni" type="text" id="dni" size="12" maxlength="12" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Nombre:</div></th>
    <td><input name="nombre" type="text" id="nombre" size="30" maxlength="30" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Apellido:</div></th>
    <td><input name="apellido" type="text" id="apellido" size="30" maxlength="30" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Sexo:</div></th>
    <td><p>
      <label>
        <input type="radio" name="sexo" value="Masculino" />
        Masculino</label>
      <br />
      <label>
        <input type="radio" name="sexo" value="Femenino" />
        Femenino</label>
      <br />
    </p>    <label></label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Educación Culminada: </div></th>
    <td><label>
      <input name="primaria" type="checkbox" id="primaria" value="Primaria" />
      Primaria 
      <input name="secundaria" type="checkbox" id="secundaria" value="Secundaria" />
      Secundaria 
      <input name="universitaria" type="checkbox" id="universitaria" value="Universitaria" />
      Universitaria 
      <input name="postgrado" type="checkbox" id="postgrado" value="Post-Grado" />
      Post-Grado</label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Departamento:</div></th>
    <td><label>
      <select name="departamento[]" size="1" id="departamento[]">
        <option>SISTEMAS</option>
        <option>RECURSO HUMANOS</option>
        <option>CONTABILIDAD</option>
        <option>ADMINISTRACI&Oacute;N</option>
        <option>FINANZAS</option>
      </select>
    </label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Sueldo:</div></th>
    <td><label>
      <input name="sueldo" type="text" id="sueldo" size="20" maxlength="20" />
    </label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Porcentaje de Aumento: </div></th>
    <td><label>
      <input name="aumento" type="text" id="aumento" size="3" maxlength="3" />
    </label></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Observaciones:</div></th>
    <td><label>
      <textarea name="observaciones" id="observaciones"></textarea>
    </label></td>
  </tr>
  <tr>
    <th scope="row"><label>
    <input type="submit" name="Submit" value="Enviar" />
    </label></th>
    <td><label>
    <input type="reset" name="Submit2" value="Restablecer" />
    </label></td>
  </tr>
</table>

</form>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</body>
</html>