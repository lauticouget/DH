<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Programa que Captura las variables y Cálcula Aumento Método Post</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/master.css">
</head>
<body class="calculo">
<?php


//Programa que recibe los datos de las variables del programa Captura_Aumento.php

$dni = $_POST['dni'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
//Lo realice así para que practiquen condiciones
if (isset($_POST['sexo'])){ 
    $sexo = $_POST['sexo'];
}else{ $sexo = "";}


if (isset($_POST['primaria'])) {
    $estudios = $_POST['primaria'];
}elseif(isset($_POST['secundaria'])){
    $estudios = $_POST['secundaria'];
}elseif(isset($_POST['universitaria'])){
    $estudios = $_POST['universitaria'];
}elseif(isset($_POST['postgrado'])){
    $estudios = $_POST['postgrado'];
}

$sueldo = $_POST['sueldo'];
$aumento = $_POST['aumento'];
$observaciones = $_POST['observaciones'];
//Aqui comienzo a mostrar los datos que ya recibi en las variables
echo "<h1>"."LOS DATOS ESPECIFICADOS FUERON:"."</h1>"."<br>";
echo "<h2>"."DNI:  "." ". $dni."</h2". "<br>";
echo "<h2>"."Nombre:  "." ". $nombre."</h2". "<br>";
echo "<h2>"."Apellido:  "." ". $apellido."</h2"."<br>";
echo "<h2>"."Sexo:  "." ". $sexo."</h2". "<br>";
echo "<h2>"."Usted academicamente culminó:  "." ". $estudios."</h2". "<br>";
echo "<h2>"."Su sueldo Actual es:  "." ".$sueldo."</h2". "<br>";
echo "<h2>"."Porcentaje de aumento:  "." ".$aumento."</h2". "<br>";
$nuevosueldo = (($sueldo * $aumento)/100) + $sueldo. "<br>";
echo "<h2>"."Su nuevo sueldo es:  "." ".$nuevosueldo."</h2". "<br>";
echo "<h2>"."Observaciones:  "." ".$observaciones."</h2" ."<br>";
if (is_array($_POST['departamento'])) {
 foreach($_POST['departamento'] as $mostrar)
{
echo "<h2>"."Departamento donde Labora:  "." ".$mostrar."</h2". "<br>";
}
}
echo "<br>";

?>
<a href="index.html">Volver</a>
</body>
</html>