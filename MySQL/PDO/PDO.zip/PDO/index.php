<?php

// Config para el modo de muestra de errores
// setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

// Escribir codigo a partir de esta linea
















// No escribir codigo debajo de esta linea
require 'views/index.view.php';